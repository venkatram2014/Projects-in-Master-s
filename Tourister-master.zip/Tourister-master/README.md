# Tourister
Tourister provides you ability to view your nearest attrcations and view tours. You can also view pictures of the place and share them with your friends. Mark places as favorites and the view them later. Select places from a wide variety of categories ranging from Architecture , Food etc.
