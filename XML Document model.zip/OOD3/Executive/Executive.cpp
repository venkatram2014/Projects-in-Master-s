#include "Executive.h"


Executive::Executive()
{
}


Executive::~Executive()
{
}
int main()
{

}