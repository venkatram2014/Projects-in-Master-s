/////////////////////////////////////////////////////////////////////////
// Message.h - Message helps in creating the message header which      //
//             contains set and get functions                          //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  Provides class that creates message header with set and get functions.
*  setcommand():
*  assigns command value
*  setclientip():
*  assigns client ip value.
*  setclientport():
*  assigns client port value.
*  setserverip():
*  assigns server ip value.
*  setserverport():
*  assigns server port value.
*  setfilename():
*  assigns filename.
*  Required Files:
*  ---------------
*  Message.h, Message.cpp
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9th Apr 15
*/
#pragma once
#include <string>
#include <iostream>
class Message
{
public:
	Message();
	~Message();
	void setcommand(std::string cmd);
	void setclientip(std::string cip);
	void setclientport(std::string cp);
	void setserverip(std::string sip);
	void setserverport(std::string sp);
	void setfilename(std::string fname);
	void setfilebody(std::string fbody);
	std::string getcommand();
	std::string getclientip();
	std::string getclientport();
	std::string getserverip();
	std::string getserverport();
	std::string getfilename();
	std::string getfilebody();
private:
	std::string command;
	std::string clientip;
	std::string clientport;
	std::string serverip;
	std::string serverport;
	std::string filename;
	std::string filebody;
};
