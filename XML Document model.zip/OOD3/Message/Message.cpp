/////////////////////////////////////////////////////////////////////////
// Message.cpp - C++ wrapper for creating message Header.              //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
#include "Message.h"


Message::Message()
{
}


Message::~Message()
{
}
void Message::setcommand(std::string cmd)
{
	command = cmd;
}
void Message::setclientip(std::string cip)
{
	clientip = cip;
}
void Message::setclientport(std::string cp)
{
	clientport = cp;
}
void Message::setserverip(std::string sip)
{
	serverip = sip;
}
void Message::setserverport(std::string sp)
{
	serverport = sp;
}
void Message::setfilename(std::string fname)
{
	filename = fname;
}
void Message::setfilebody(std::string fbody)
{
	filebody = fbody;
}
std::string Message::getcommand()
{
	return command;
}
std::string Message::getclientip()
{
	return clientip;
}
std::string Message::getclientport()
{
	return clientport;
}
std::string Message::getserverip()
{
	return serverip;
}
std::string Message::getserverport()
{
	return serverport;
}
std::string Message::getfilename()
{
	return filename;
}
std::string Message::getfilebody()
{
	return filebody;
}
#ifdef TEST_Message
int main()
{
	Message *m = new Message();
	std::string a;
	std::string b;
	std::string c;
	std::string d;
	std::string e;
	std::string f;
	std::string g;
	m->setclientip(b);
	m->setcommand(a);
	m->setclientport(c);
	m->setserverip(d);
	m->setserverport(e);
	m->setfilename(f);
	m->setfilebody(g);
	m->getclientip();
	m->getclientport();
	m->getcommand();
	m->getfilebody();
	m->getfilename();
	m->getserverip();
	m->getserverport();
}
#endif