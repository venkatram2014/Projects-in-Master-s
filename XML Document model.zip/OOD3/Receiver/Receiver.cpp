/////////////////////////////////////////////////////////////////////////
// Receiver.cpp - C++ wrapper for receiving messages and writing them  //
//                to a file.                                           //
// ver 1.0                                                             //
// Kiran Jujjavarapu, CSE687 - Object Oriented Design, Spring 2015     //
// Syracuse University, 315 751-3045, kjujjava@syr.edu                 //
//---------------------------------------------------------------------//
// Kiran Jujjavarapu (c) copyright 2015                                //
// All rights granted provided this copyright notice is retained       //
//---------------------------------------------------------------------//
// Application: OOD Projects #3, #4                                    //
// Platform:    Visual Studio 2013, Dell 2720, Win 8.1 pro             //
/////////////////////////////////////////////////////////////////////////
#include "Receiver.h"
#include <iostream>
#include <fstream>
#include <string>
Receiver::Receiver()
{
}


Receiver::~Receiver()
{
}
void Receiver::receivemsg(std::string msg, std::ofstream &os)
{
	if (msg=="TEST_STOP")
	{
		return;
	}
	std::size_t a = msg.find("*");
	std::string f;
	std::size_t index = msg.find("filebody:");
	//std::ofstream file;
	//file.open("../test/f.txt",std::ios::app);
	std::string msg1;
	for (std::size_t i = index+9; i < a; i++)
	{
		
		msg1 = msg1 + msg.at(i);
	}
	os << msg1<<"\n";
	os.close();
}

#ifdef TEST_Receiver
int main()
{
	Receiver *r = new Receiver();
	std::string msg;
	std::ofstream o;
	r->receivemsg(msg, o);
}
#endif