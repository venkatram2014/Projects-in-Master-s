

import java.io.FileNotFoundException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import com.vmware.vim25.FileFaultFaultMsg;
import com.vmware.vim25.InsufficientResourcesFaultFaultMsg;
import com.vmware.vim25.InvalidCollectorVersionFaultMsg;
import com.vmware.vim25.InvalidDatastoreFaultMsg;
import com.vmware.vim25.InvalidLoginFaultMsg;
import com.vmware.vim25.InvalidPropertyFaultMsg;
import com.vmware.vim25.InvalidStateFaultMsg;
import com.vmware.vim25.MigrationFaultFaultMsg;
import com.vmware.vim25.TimedoutFaultMsg;
import com.vmware.vim25.VmConfigFaultFaultMsg;

public class Main {
	 public static void main(String[] args) throws InvalidPropertyFaultMsg, InvalidLoginFaultMsg, InterruptedException, VmConfigFaultFaultMsg, InsufficientResourcesFaultFaultMsg, InvalidDatastoreFaultMsg, FileFaultFaultMsg, MigrationFaultFaultMsg, InvalidStateFaultMsg, InvalidCollectorVersionFaultMsg, TimedoutFaultMsg, FileNotFoundException {
	        String url = "https://128.230.247.52/sdk";
	        String user = "vcheedel@syr.edu";
	        String password = "Ich0006428#";
	        String vmna = "venk2";	        
	        try {
	        Connection con = new Connection(url, user, password, vmna);
	        con.trustEveryone();
	        con.connect();
	        } catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	        } catch (KeyManagementException e) {
	            e.printStackTrace();
	        }

	    }

}
