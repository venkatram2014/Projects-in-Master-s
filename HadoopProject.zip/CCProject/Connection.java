

import java.util.Map;

import javax.xml.ws.BindingProvider;

import com.vmware.vim25.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import java.util.*;
public class Connection {
	
	class RemindTask extends TimerTask {
	    public void run() {
	    	try
	    	{
	    		if(sum_hostcpuload/loadcount >= 100 && sum_hostmemload/loadcount >= 2000)
	    		{
	    		VMotion vMov = new VMotion();
	            vMov.run(serviceContent, vimPort);
	            status = false;
	    		}
	    	}
	    	catch(Exception e)
	    	{
	    		
	    	}
	      //timer.cancel(); //Not necessary because we call System.exit
	      System.exit(0); //Stops the AWT thread (and everything else)
	    }
	  }
	 Boolean status = true;
	 private String url;
	    private String user;
	    private String password;	  	   
	    private int sum_hostcpuload =0;
	    private int loadcount=0;	 	  
	    private int sum_hostmemload =0;
	    Timer timer;
	    String host;
	    String givenVMName;
	    ServiceContent serviceContent;
	    ManagedObjectReference vmObjRef; 
	    ManagedObjectReference hostMoR;
	    VimService vimService;
	    VimPortType vimPort ;
	    ManagedObjectReference serviceInstance;
	    
	    public Connection(String url, String user, String password, String vmname) {
	        this.url = url;
	        this.password = password;
	        this.user = user;
	        this.givenVMName = vmname;
	    }
	    
	    public void connect() throws InvalidPropertyFaultMsg, InvalidLoginFaultMsg, InterruptedException, VmConfigFaultFaultMsg, InsufficientResourcesFaultFaultMsg, InvalidDatastoreFaultMsg, FileFaultFaultMsg, MigrationFaultFaultMsg, InvalidStateFaultMsg, InvalidCollectorVersionFaultMsg, TimedoutFaultMsg, FileNotFoundException {

	        vimService = new VimService();
	        vimPort = vimService.getVimPort();

	        Map<String, Object> ctxt = ((BindingProvider) vimPort).getRequestContext();
	        ctxt.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, url);
	        ctxt.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

	        serviceInstance = new ManagedObjectReference();
	        serviceInstance.setType("ServiceInstance");
	        serviceInstance.setValue("ServiceInstance");	       
	        try {
	            serviceContent =
	                    vimPort.retrieveServiceContent(serviceInstance);
	            vimPort.login(serviceContent.getSessionManager(), user, password, null);	          
	            do {
	            	timer = new Timer();
	            	timer.schedule(new RemindTask(), 100 * 1000);
	                DisplayResults("vm");
	                DisplayResults("host");
	                System.out.println("sleeping for 15 seconds");
	                Thread.sleep(15*1000);	                	                	                
	            } while(status);
	            
	            vimPort.logout(serviceContent.getSessionManager());

	        } catch (RuntimeFaultFaultMsg e) {
	            e.printStackTrace();
	        } catch (InvalidLocaleFaultMsg e) {
	            e.printStackTrace();
	        } 
	    }
	    
	    public RetrieveResult getVMResults(String vmname) throws InvalidPropertyFaultMsg, RuntimeFaultFaultMsg {
	        //ManagedObjectReference viewMgrRef = serviceContent.getViewManager();
	        ManagedObjectReference propColl = serviceContent.getPropertyCollector();

	        List<String> vmList = new ArrayList<String>();
	        vmList.add("VirtualMachine");
	         
	        /*ManagedObjectReference cViewRef = vimPort.createContainerView(viewMgrRef,
	                serviceContent.getRootFolder(),
	        vmList,
	        true );*/
	        
	        ManagedObjectReference vmObj = vmByVMname(vmname);
	        
	        ObjectSpec oSpec = new ObjectSpec();
	        oSpec.setObj(vmObj);
	        oSpec.setSkip(false);    
	        
	        TraversalSpec tSpec = new TraversalSpec();
	        tSpec.setName("traverseEntities");
	        tSpec.setPath("view");
	        tSpec.setSkip(false);
	        tSpec.setType("ContainerView");
	        
	        oSpec.getSelectSet().add(tSpec);
	        
	        PropertySpec pSpec = new PropertySpec();
	        pSpec.setType("VirtualMachine");
	        pSpec.getPathSet().add("name");
	        pSpec.getPathSet().add("summary.quickStats");
	        pSpec.getPathSet().add("runtime");
	            
	        PropertyFilterSpec fSpec = new PropertyFilterSpec();
	        fSpec.getObjectSet().add(oSpec);
	        fSpec.getPropSet().add(pSpec);
	        
	        List<PropertyFilterSpec> fSpecList = new ArrayList<PropertyFilterSpec>();
	        fSpecList.add(fSpec);
	        
	        RetrieveOptions ro = new RetrieveOptions();
	        RetrieveResult props = vimPort.retrievePropertiesEx(propColl,fSpecList,ro);
	        return props;
	    }
	    
	    public RetrieveResult getHostResults() throws InvalidPropertyFaultMsg, RuntimeFaultFaultMsg {
	        //ManagedObjectReference viewMgrRef = serviceContent.getViewManager();
	        ManagedObjectReference propColl = serviceContent.getPropertyCollector();

	        List<String> vmList = new ArrayList<String>();
	        vmList.add("HostSystem");
	         
	        /*ManagedObjectReference cViewRef = vimPort.createContainerView(viewMgrRef,
	                serviceContent.getRootFolder(),
	        vmList,
	        true );*/
	        
	        ManagedObjectReference vmObj = hostMoR;
	        
	        ObjectSpec oSpec = new ObjectSpec();
	        oSpec.setObj(vmObj);
	        oSpec.setSkip(false);    
	        
	        TraversalSpec tSpec = new TraversalSpec();
	        tSpec.setName("traverseEntities");
	        tSpec.setPath("view");
	        tSpec.setSkip(false);
	        tSpec.setType("ContainerView");
	        
	        oSpec.getSelectSet().add(tSpec);
	        
	        PropertySpec pSpec = new PropertySpec();
	        pSpec.setType("HostSystem");
	        pSpec.getPathSet().add("name");
	        pSpec.getPathSet().add("summary.quickStats");
	        pSpec.getPathSet().add("runtime");
	            
	        PropertyFilterSpec fSpec = new PropertyFilterSpec();
	        fSpec.getObjectSet().add(oSpec);
	        fSpec.getPropSet().add(pSpec);
	        
	        List<PropertyFilterSpec> fSpecList = new ArrayList<PropertyFilterSpec>();
	        fSpecList.add(fSpec);
	        
	        RetrieveOptions ro = new RetrieveOptions();
	        RetrieveResult props = vimPort.retrievePropertiesEx(propColl,fSpecList,ro);
	        return props;
	    }
	    
	    public void DisplayResults(String val) throws InvalidPropertyFaultMsg, RuntimeFaultFaultMsg, VmConfigFaultFaultMsg, InsufficientResourcesFaultFaultMsg, InvalidDatastoreFaultMsg, FileFaultFaultMsg, MigrationFaultFaultMsg, InvalidStateFaultMsg, InvalidCollectorVersionFaultMsg, TimedoutFaultMsg, FileNotFoundException {
	        RetrieveResult props;
	        Boolean setHostName = false;
	        File file = new File("Serverlogs.txt");
    		PrintWriter print = new PrintWriter(file);
	        if(val.equalsIgnoreCase("VM")) {
	             props = getVMResults(givenVMName);
	        } else {
	            props = getHostResults();
	            setHostName = true;
	        }
	        
	        if (props != null) {
	            for (ObjectContent oc : props.getObjects()) {
	                String name = null;
	                Object value = null;
	                
	                List<DynamicProperty> dps = oc.getPropSet();
	                if (dps != null) {
	                    for (DynamicProperty dp : dps) {
	                        name = dp.getName();
	                        value = dp.getVal();
	                        
	                        if ("summary.quickStats".equals(name)) {
	                            if (value instanceof VirtualMachineQuickStats) {
	                                System.out.print(" VMUsage:");
	                                VirtualMachineQuickStats vmqs =
	                                        (VirtualMachineQuickStats) value;
	                                String cpu =
	                                        vmqs.getOverallCpuUsage() == null ? "unavailable"
	                                                : vmqs.getOverallCpuUsage().toString();
	                                String memory =
	                                        vmqs.getHostMemoryUsage() == null ? "unavailable"
	                                                : vmqs.getHostMemoryUsage().toString();
	                             
	                                /*System.out.println("   Guest Status: "
	                                        + vmqs.getGuestHeartbeatStatus().toString());*/
	                                System.out.print("   CPU Load : " + cpu);
	                                System.out.print("   Memory Load : " + memory);	                                
	                        		print.print("Virtual Machine Usage : ");
	                        		print.print("CPU Load : " + cpu);
	                        		print.print("Memory Load : " + memory);
	                                
	                            } else if (value instanceof HostListSummaryQuickStats) {
	                                System.out.print("\t\tHostUsage:");
	                                HostListSummaryQuickStats hsqs =
	                                        (HostListSummaryQuickStats) value;
	                                String cpu =
	                                        hsqs.getOverallCpuUsage() == null ? "unavailable"
	                                                : hsqs.getOverallCpuUsage().toString();
	                                String memory =
	                                        hsqs.getOverallMemoryUsage() == null ? "unavailable"
	                                                : hsqs.getOverallMemoryUsage().toString();
	                                System.out.print("   CPU Load : " + cpu);
	                                System.out.println("   Memory Load : " + memory);
	                                print.print("\t\tHost Usage : ");
	                        		print.print("CPU Load : " + cpu);
	                        		print.println("Memory Load : " + memory);
	                                sum_hostcpuload = sum_hostcpuload + Integer.parseInt(cpu);
	                                sum_hostmemload = sum_hostmemload + Integer.parseInt(memory);
	                                loadcount++;
	                            }
	                        } else if ("runtime".equals(name)) {
	                            if (value instanceof VirtualMachineRuntimeInfo) {
	                                VirtualMachineRuntimeInfo vmri =
	                                        (VirtualMachineRuntimeInfo) value;
	                                
	                               hostMoR =vmri.getHost();
	                               //System.out.println("host is:"+ hostMoR.getValue());
	                                
	                            } else if (value instanceof HostRuntimeInfo) {
	                                // not needed for now
	                            }
	                        } else if ("name".equals(name)) {
	                            //System.out.println("\n\n=>"+"   " + value);
	                            if(setHostName) {
	                                host = value.toString();
	                            }
	                        } else {
	                            System.out.println("   " + value.toString());
	                        }
	                    }
	                }
	            }
	        }	       
	    }
	    
	    public ManagedObjectReference vmByVMname(
	            final String vmName
	    ) throws InvalidPropertyFaultMsg, RuntimeFaultFaultMsg {
	        
	        ManagedObjectReference retVal = null;
	        //ManagedObjectReference rootFolder = serviceContent.getRootFolder();
	        
	        ManagedObjectReference viewMgrRef = serviceContent.getViewManager();
	        ManagedObjectReference propColl = serviceContent.getPropertyCollector();
	        
	        

	        List<String> vmList = new ArrayList<String>();
	        vmList.add("VirtualMachine");
	         
	        ManagedObjectReference cViewRef = vimPort.createContainerView(viewMgrRef,
	                serviceContent.getRootFolder(),
	        vmList,
	        true );
	        
	        
	        ObjectSpec oSpec = new ObjectSpec();
	        oSpec.setObj(cViewRef);
	        oSpec.setSkip(true);
	        
	        
	        TraversalSpec tSpec = new TraversalSpec();
	        tSpec.setName("traverseEntities");
	        tSpec.setPath("view");
	        tSpec.setSkip(false);
	        tSpec.setType("ContainerView");
	        
	        oSpec.getSelectSet().add(tSpec);
	        
	        PropertySpec pSpec = new PropertySpec();
	        pSpec.setType("VirtualMachine");
	        pSpec.getPathSet().add("name");


	        
	        
	        PropertyFilterSpec fSpec = new PropertyFilterSpec();
	        fSpec.getObjectSet().add(oSpec);
	        fSpec.getPropSet().add(pSpec);
	        
	        List<PropertyFilterSpec> fSpecList = new ArrayList<PropertyFilterSpec>();
	        fSpecList.add(fSpec);
	        
	        RetrieveOptions ro = new RetrieveOptions();
	        List<ObjectContent> listobcont = vimPort.retrievePropertiesEx(propColl,fSpecList,ro).getObjects();
	        


	        if (listobcont != null) {
	            for (ObjectContent oc : listobcont) {
	                ManagedObjectReference mr = oc.getObj();
	                String vmnm = null;
	                List<DynamicProperty> dps = oc.getPropSet();
	                if (dps != null) {
	                    for (DynamicProperty dp : dps) {
	                        vmnm = (String) dp.getVal();
	                    }
	                }
	                if (vmnm != null && vmnm.equals(vmName)) {
	                    //System.out.println(vmName);
	                    retVal = mr;
	                    break;
	                }
	            }
	        }
	        return retVal;
	    }
	    
	    
	    
	    private static class TrustAllTrustManager implements javax.net.ssl.TrustManager, javax.net.ssl.X509TrustManager {

	        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	            return null;
	        }

	        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType)
	            throws java.security.cert.CertificateException {
	            return;
	        }

	        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType)
	            throws java.security.cert.CertificateException {
	            return;
	        }
	    }
	    
	    public  void trustEveryone()
	            throws NoSuchAlgorithmException, KeyManagementException {
	        // Declare a host name verifier that will automatically enable
	        // the connection. The host name verifier is invoked during
	        // the SSL handshake.
	        javax.net.ssl.HostnameVerifier verifier = new HostnameVerifier() {
	            public boolean verify(String urlHostName, SSLSession session) {
	                return true;
	            }
	        };
	        // Create the trust manager.
	        javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
	        javax.net.ssl.TrustManager trustManager = new TrustAllTrustManager();
	        trustAllCerts[0] = trustManager;

	        // Create the SSL context
	        javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("SSL");

	        // Create the session context
	        javax.net.ssl.SSLSessionContext sslsc = sc.getServerSessionContext();

	        // Initialize the contexts; the session context takes the trust manager.
	        sslsc.setSessionTimeout(0);
	        sc.init(null, trustAllCerts, null);

	        // Use the default socket factory to create the socket for the secure connection
	        javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Set the default host name verifier to enable the connection.
	        HttpsURLConnection.setDefaultHostnameVerifier(verifier);
	    }

}
